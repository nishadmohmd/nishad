import React from "react"
import { decrement,increment, reset } from "../../slice/counterSlice";
import { useSelector, useDispatch } from "react-redux";
let count=0;

 function Counter(){

    const selector = useSelector((state)=>state.Counter)
    console.log(selector);
    function handleClick(){
        dispatch(increment())
    }

    const dispatch=useDispatch()
    
  return (
    <div>
      <div>
        <h2>Counter: {count}</h2>
        <div>
          <button onClick={increment}>
            Increment
          </button>
          <button onClick={decrement}>
            Decrement
          </button>
          <button onClick={reset}>
            Reset
          </button>
        </div>
      </div>
    </div>
  );
}

export default Counter;