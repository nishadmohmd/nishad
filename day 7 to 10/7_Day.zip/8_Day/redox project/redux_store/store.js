import { configureStore } from "@reduxjs/toolkit";              // Default Store
import counterSlice from "../slice/counterSlice"
const store = configureStore({
    reducer: {counter:counterSlice}                                               // default reducer 
})
// Exporting the Function
// export const {} =  counter.action;

export default store;