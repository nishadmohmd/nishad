import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { decrement, increment, reset } from "../../slice/counterSlice";

function Counter() {
  const count = useSelector((state) => state.counter.count);
  const dispatch = useDispatch();


  const addValue = () => {
    const value = prompt("Enter the value to add:");  
    if (value !== null && !isNaN(value)) {
      dispatch(increment(Number(value)));  
    } else {
      alert("Please enter a valid number!");
    }
  };

  return (
    <div>
      <div>
        <h2>Counter: {count}</h2>
        <div>
          <button onClick={() => dispatch(increment())}>Increment</button>
          <button onClick={() => dispatch(decrement())}>Decrement</button>
          <button onClick={() => dispatch(reset())}>Reset</button>
          <button onClick={addValue}>Add Value</button> 
        </div>
      </div>
    </div>
  );
}

export default Counter;