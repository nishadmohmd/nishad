// // catching events


// const http=require("http")
// const server=http.createServer()
// server.on("request",(req,res)=>
// {
//     console.log("requested");
// })
// server.listen(5000)

// // custom events

// const EventEmitter = require("events"); // Correct import of EventEmitter
// const customEvent = new EventEmitter(); // Create an instance of EventEmitter

// // Listen for a custom event named "cs"
// customEvent.on("cs", () => {
//     console.log("cs is called"); // This will run when the "cs" event is emitted
// });

// // Trigger the "cs" event
// customEvent.emit("cs");


// const express = require("express");
// const app = express();
// app.get("/", (req, res) => {
// //    res.json({ok:true});
// // res.status(200).sendFile(__dirname+"/index.html");
// res.setHeader("Content-Type", "text/html");


// });
// app.listen(3000,()=>{
//     console.log("Server is running on port 3000")
// })



const {getProducts,getProduct1,patchProduct,putProduct,deleteProduct,postProduct}=require("./RouteHandler/ProductFunctions")
const express = require("express");
const app = express();
const morgan=require("morgan")
const fs = require("fs");
const path = require("path");


app.use(express.json());

const jsonData = JSON.parse(fs.readFileSync(path.join(__dirname, "model", "product.json"), "utf-8"));

app.use(morgan("dev"));


app.listen(9706, () => {
    console.log("Server is running at http://127.0.0.1:9706");
});