const express = require('express');
const {getProducts,getProductById,createProduct,updateProduct,deleteProduct} = require("../routeHandler/productFunction");
const productRoutes=express.Router()

productRoutes.route("/").
get(getProducts).
post(createProduct)

productRoutes.route("/:id")
.get(getProductById)
.delete(deleteProduct)
.patch(updateProduct)
.put(updateProduct)

module.exports=productRoutes