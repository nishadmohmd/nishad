function Content({pData}) {
  let cData="This data is from child";
  function handleclick(){
    pData(cData);
  }
  return (
    <div>
      <button onClick={()=>handleclick("You clicked the button")}>click me</button>
      {/* {name} */}

    </div>
  )
}

export {Content};