
import { BrowserRouter,Routes,Route, Router } from "react-router-dom";
import Home from "./Home";
import Contact from "./Contact";
import About from "./About";
import OldBook from "./OldBook";
import NewBook from "./NewBook";
import User from "./User";
import { Link } from "react-router-dom";
import './App.css'
function App() 
{
  return (
    <>
    
    <BrowserRouter>
    <ul>
      <li><Link to="/home">home</Link></li>
      <li><Link to="/about">about</Link></li>
      <li><Link to="/contact">contact</Link></li>
      
    </ul>
      <Routes>
        <Route path='/home' element={<Home/>}/>
        <Route path='/about' element={<About/>}/>
        <Route path='/contact' element={<Contact/>}/>
        <Route path='/books'>
        <Route path='newbooks' element={<NewBook/>}/>
        <Route path='oldbooks' element={<OldBook/>}/>
        </Route>
        
        <Route path='/user/:id1' element={<User/>}/>
      </Routes>
    </BrowserRouter>
    </>
    )
}
export {App}
