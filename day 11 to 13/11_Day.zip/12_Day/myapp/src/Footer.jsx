import React from 'react'
import { useState , useRef} from 'react';
import { useContext } from 'react';
import temp from './ContextApi';
const Footer = () => {
    const refer=useRef()
  const [data,setData]=useState(0);
  
  function handleClick()
  {
    refer.current.focus()
  }
  let datafromglobal = useContext(temp)
  return (
 
      <div>
        {datafromglobal}
       <input ref={refer} type = "text"/>
        <button onClick={handleClick}>Focus</button>
      </div>
      
    
  )
}

export {Footer}