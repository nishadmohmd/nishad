
function Button() {
  return (
    <button>hello this is button</button>
  )
}

function H1_tag() {
    return (
      <h1>hello this is h1 tag</h1>
    )
  }

  function Para() {
    return (
      <p>hello this is paragraph tag</p>
    )
  }

  function H2_tag() {
    return (
      <h2>Hello this is h2 tag</h2>
    )
  }
export {Para,H2_tag,H1_tag,Button};
