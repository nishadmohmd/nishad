import React from 'react'
import { useParams } from 'react-router-dom'
import { useNavigate } from 'react-router-dom';
function User() {
    const routeParam = useParams();
    console.log(routeParam);
    const navigate=useNavigate();
    function handleclick(){
        navigate('/home');
    }
  return (
    <div>
       User:{routeParam.id1}
       <button onClick={handleclick}>click</button>
    </div>
  )
}

export default User