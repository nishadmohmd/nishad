import React from 'react'
function Form() {
  return (
    <div>
        <form action="">
            <label htmlFor="">Email</label>
            <input type="text" /><br />
            <label htmlFor="">Password</label>
            <input type="text" />
        </form>
    </div>
  )
}

export default Form