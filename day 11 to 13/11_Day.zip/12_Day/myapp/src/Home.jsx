import React from 'react';
import Form from './Form';

function Home() {
  return (
    <div>
      <h1 className="bg-teal-400 w-10"
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "90vh",
        }}  >
        Hello from Home
      </h1>
    </div>
  );
}

export default Home;
