import React from 'react'
import { useEffect } from 'react';
import { useFetcher } from './useFetcher';
function ApiCall() {
    // useEffect(()=>{
    //     const getData = async ()=>{
    //         let res=await fetch("https://jsonplaceholder.typicode.com/posts");
    //         let resParse = await res.json()
    //         console.log(resParse);
    //     }
    //     getData()
    // })
    let hookresponse=useFetcher("https://jsonplaceholder.typicode.com/todos/1");
    console.log(hookresponse);
   
  return (
    <div>ApiCall</div>
  )
}

export {ApiCall};