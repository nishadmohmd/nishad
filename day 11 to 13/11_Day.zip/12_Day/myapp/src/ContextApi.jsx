import { createContext } from "react";
const temp = createContext();
export default temp;