import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import {App} from './App.jsx'
import {Fun} from './header.jsx'
import { Footer } from './Footer.jsx'
import temp from './ContextApi.jsx'
import {ApiCall} from "./Apicall" 
let data = "global data";
createRoot(document.getElementById('root')).render(
  <temp.Provider value = {data}>
    <App/>
  </temp.Provider>
 
)
