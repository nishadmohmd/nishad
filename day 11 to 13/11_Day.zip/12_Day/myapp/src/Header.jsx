const Fun=()=>{
    // if(true){
    //     return(
    //         <h1>It is for client</h1>
    //     )
    // }
    // else{

    // }
    // return(
    //     <div>
    //         {/*data.map((i,k)=>{
    //             return(
    //                 <li key={k}>{i}</li>
    //             )
    //         })*/}
    //     </div>
    // )
    // let data = true;
    // return(
    //     <>
        
    //         {data && 
    //             <h1>Yeah it is </h1>
    //         }
        
    //     </>
    // )
    let data = []
    return (
        <>
        {/*data.length>0 &&
            <h1>Yeah correct</h1>
            
        */}
        {data.length == 0?<h1>yes there is a data</h1>:<h1>there is no data here</h1>}
        </>
    )
}
export {Fun};


