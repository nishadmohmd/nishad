import React from 'react'
import { useRef,useState } from 'react'
function Todo() {
    const[data,setData]=useState([]);
    const refer=useRef()
    function handleclick(){
        setData([...data,{task:refer.current.value}])
        refer.current.value="";
    }
  return (
    <div>
        <h1>To do list</h1>
        <input ref = {refer} type="text" />
        <button onClick={handleclick}>Save</button>
        {data.map(i=>
            <li>{i.task}</li>
        )}
    </div>
  )
}

export {Todo}

// intially create a input box and render it
// filter method
