const mongoose = require("mongoose")

async function DB(){
    await mongoose.connect("mongodb://localhost:27017/todo");
    console.log("Connected to MongoDB");
}

module.exports=DB;