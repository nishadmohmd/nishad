let link = document.getElementById('link');
let btn = document.getElementById('btn');
let toDisplay = document.getElementById('qrCode');

btn.addEventListener('click', (e) => {
    e.preventDefault();
    console.log("Button clicked");
    generateQRCode();
});



////////FOR REFERENCE ////////



// async  function generateQRCode() {
//     let response = await fetch('http://localhost:3087/qr',
//     {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json'
//         },
//         body: JSON.stringify({data: link.value})
//     })
//     response = await response.json();
//     console.log(response);
//     let img = document.createElement('img');
//     img.src = response;
//     toDisplay.innerHTML = "";
//     toDisplay.appendChild(img);
// }




async  function generateQRCode() {
    let response = await fetch(http://localhost:3087/qr?link=${link.value})
    response = await response.json();
    console.log(response);
    let img = document.createElement('img');
    img.src = response;
    toDisplay.innerHTML = "";
    toDisplay.appendChild(img);
}