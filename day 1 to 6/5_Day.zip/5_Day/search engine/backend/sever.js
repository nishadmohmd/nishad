const express = require("express")
const app = express()
const db = require('./DB/db')
const courseSchema = require("./models/schema")
const cors=require("cors")
app.use(cors())
app.get("/api/v1/search",async (req,res)=>{
    await db()

    const cors = require('cors');
    app.use(cors())
    
    let query=req.query.search
    console.log(query)
    
    let test=await courseSchema.find()
    console.log(test);
    
    let course=await courseSchema.find({title:{$regex:query,$options:"i"}})
    res.json(course)
})
app.listen(3000,()=>{
    console.log("Server is running on port 3000")
})
