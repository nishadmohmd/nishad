const {Schema, model} = require('mongoose');
const courseDetail = new Schema({
    title:String,
    description:String
})
module.exports = model('course',courseDetail)