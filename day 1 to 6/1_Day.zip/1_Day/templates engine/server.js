const express = require("express");
const app = express();
const path = require("path");
const {engine} = require("express-handlebars")

const pug = require("pug");
const ejs = require("ejs")
app.use(express.static(path.join(__dirname, "public"))); // This is to serve static files like CSS, JS, images, etc.


app.engine("hbs", engine({extname: "hbs",defaultLayout:false})); // This is to use handlebars template engine

app.set("view engine", "hbs");


app.get("/home", (req, res) => {
    let data = "Test Value";
    let array = [1,2,3,4,5]

    res.render("index", {data, array});
})

app.get("/about", (req, res) => {
    // let array = [1,2,3,4,5]
    res.render("about", {array});
})

app.get("/contact", (req, res) => {
    let title = "Contact";
    res.render("contact", {title});
})

app.listen(3000, () => {
  console.log("Server is running on port 3000");
});