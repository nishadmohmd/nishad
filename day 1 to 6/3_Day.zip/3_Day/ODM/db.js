db.js

const mongoose = require("mongoose");
const cust = require("./schema")
async function db(){
    try{
        await mongoose.connect('mongodb://localhost:27017/customer');
        console.log("database successfully connected");
    }catch(e){
        console.log("error on connection db");
    } 
    // const newCustomer = new cust({
    //     name:"praveen kumar",
    //     age:21,
    //     friend:'67985e814d2972b2534b86a3',
    //     address:{
    //         pincode:123456,
    //         state:"TN"
    //     },
    //     hobbies:["gaming","singing"]

    // })

    const customerData=await cust.findById('667985e814d2972b2534b86a3').populate("friend")
    console.log(customerData)

}
db()